Shattered Pixel Dungeon
=======================

A Roguelike RPG, with randomly generated levels, items, enemies, and traps!
Based on the source code of Pixel Dungeon, by Watabou.

Shattered Pixel Dungeon uses gradle and is most easily compiled/edited using Android Studio.

Shattered Pixel Dungeon on Google Play:
https://play.google.com/store/apps/details?id=com.shatteredpixel.shatteredpixeldungeon

On Amazon:
https://www.amazon.com/Shattered-Pixel-Dungeon/dp/B00OH2C21M

On F-Droid (Which compiles directly from this source code):
https://f-droid.org/repository/browse/?fdid=com.shatteredpixel.shatteredpixeldungeon

Official web-site: 
http://www.shatteredpixel.com

Developer's blog: 
http://shatteredpixel.tumblr.com/

Source code of original Pixel Dungeon:
https://github.com/watabou/pixel-dungeon
